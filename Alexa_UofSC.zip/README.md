# Alexa_UofSC

## Intent Names

- searchClass
-- Name of the course category
--- name of the coruse number

- find bus
